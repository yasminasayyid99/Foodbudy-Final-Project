# Models package
# Import models directly in routes to avoid circular imports